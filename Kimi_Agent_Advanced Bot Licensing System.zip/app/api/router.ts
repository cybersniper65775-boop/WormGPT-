import { authRouter } from "./auth-router";
import { portalRouter } from "./portal-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  portal: portalRouter,
});

export type AppRouter = typeof appRouter;
