import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import { cors } from "hono/cors";
import type { HttpBindings } from "@hono/node-server";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "./router";
import { createContext } from "./context";
import { env } from "./lib/env";
import { createOAuthCallbackHandler } from "./kimi/auth";
import { Paths } from "@contracts/constants";
import { getDb } from "./queries/connection";
import { webUsers } from "../db/schema";
import { eq } from "drizzle-orm";
import { createHash, randomBytes } from "crypto";

const app = new Hono<{ Bindings: HttpBindings }>();

// CORS
app.use("*", cors({
  origin: ["http://localhost:3000", "http://localhost:5173"],
  allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowHeaders: ["Content-Type", "Authorization", "X-Admin-Secret"],
  credentials: true,
}));

app.use(bodyLimit({ maxSize: 50 * 1024 * 1024 }));

// ─── Portal Login (Direct HTTP) ──────────────────────────────
app.post("/api/portal/login", async (c) => {
  try {
    const body = await c.req.json<{ username: string; password: string }>();
    const { username, password } = body;

    if (!username || !password) {
      return c.json({ success: false, error: "Username and password required" }, 400);
    }

    const db = getDb();
    const users = await db
      .select()
      .from(webUsers)
      .where(eq(webUsers.username, username))
      .limit(1);

    if (users.length === 0) {
      return c.json({ success: false, error: "Invalid credentials" }, 401);
    }

    const user = users[0];

    if (!user.isActive) {
      return c.json({ success: false, error: "Account is disabled" }, 403);
    }

    if (user.expiresAt && new Date(user.expiresAt) < new Date()) {
      return c.json({ success: false, error: "Subscription has expired" }, 403);
    }

    const hashedInput = createHash("sha256").update(password).digest("hex");
    if (hashedInput !== user.passwordHash) {
      return c.json({ success: false, error: "Invalid credentials" }, 401);
    }

    // Update last login
    await db
      .update(webUsers)
      .set({ lastLoginAt: new Date() })
      .where(eq(webUsers.id, user.id));

    const token = randomBytes(32).toString("hex");

    return c.json({
      success: true,
      token,
      user: {
        id: user.id,
        username: user.username,
        displayName: user.displayName,
        tier: user.tier,
        expiresAt: user.expiresAt,
        isActive: user.isActive,
      },
    });
  } catch (error) {
    console.error("Portal login error:", error);
    return c.json({ success: false, error: "Internal server error" }, 500);
  }
});

// ─── OAuth & tRPC ──────────────────────────────────────────────
app.get(Paths.oauthCallback, createOAuthCallbackHandler());
app.use("/api/trpc/*", async (c) => {
  return fetchRequestHandler({
    endpoint: "/api/trpc",
    req: c.req.raw,
    router: appRouter,
    createContext,
  });
});
app.all("/api/*", (c) => c.json({ error: "Not Found" }, 404));

export default app;

if (env.isProduction) {
  const { serve } = await import("@hono/node-server");
  const { serveStaticFiles } = await import("./lib/vite");
  serveStaticFiles(app);

  const port = parseInt(process.env.PORT || "3000");
  serve({ fetch: app.fetch, port }, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}
