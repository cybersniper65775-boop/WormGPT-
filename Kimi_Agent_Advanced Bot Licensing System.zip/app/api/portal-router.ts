import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { webUsers } from "../db/schema";
import { eq } from "drizzle-orm";
import { createHash, randomBytes } from "crypto";

// Simple password hash (SHA-256)
function hashPassword(password: string): string {
  return createHash("sha256").update(password).digest("hex");
}

// In-memory token store (use Redis in production)
const tokenStore = new Map<string, { userId: number; expires: Date }>();

export const portalRouter = createRouter({
  login: publicQuery
    .input(
      z.object({
        username: z.string().min(1).max(255),
        password: z.string().min(1).max(255),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      const users = await db
        .select()
        .from(webUsers)
        .where(eq(webUsers.username, input.username))
        .limit(1);

      if (users.length === 0) {
        return { success: false, error: "Invalid credentials" };
      }

      const user = users[0];

      if (!user.isActive) {
        return { success: false, error: "Account is disabled" };
      }

      if (user.expiresAt && new Date(user.expiresAt) < new Date()) {
        return { success: false, error: "Subscription has expired" };
      }

      const hashedInput = hashPassword(input.password);
      if (hashedInput !== user.passwordHash) {
        return { success: false, error: "Invalid credentials" };
      }

      await db
        .update(webUsers)
        .set({ lastLoginAt: new Date() })
        .where(eq(webUsers.id, user.id));

      const token = randomBytes(32).toString("hex");
      tokenStore.set(token, {
        userId: user.id,
        expires: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      });

      return {
        success: true,
        token,
        user: {
          id: user.id,
          username: user.username,
          displayName: user.displayName,
          tier: user.tier,
          expiresAt: user.expiresAt,
          isActive: user.isActive,
        },
      };
    }),
});
