import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  int,
  boolean,
  json,
} from "drizzle-orm/mysql-core";

// ─── OAuth Users (from auth feature) ──────────────────────────
export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

// ─── Web Portal Users (admin-created with username/password) ──
export const webUsers = mysqlTable("web_users", {
  id: serial("id").primaryKey(),
  telegramId: varchar("telegram_id", { length: 50 }),
  username: varchar("username", { length: 255 }).notNull().unique(),
  passwordHash: varchar("password_hash", { length: 255 }).notNull(),
  displayName: varchar("display_name", { length: 255 }),
  tier: mysqlEnum("tier", ["free", "pro", "max", "web", "admin"]).default("web").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull().$onUpdate(() => new Date()),
  lastLoginAt: timestamp("last_login_at"),
  subscriptionDays: int("subscription_days").default(0),
});

// ─── Chat Sessions ────────────────────────────────────────────
export const chatSessions = mysqlTable("chat_sessions", {
  id: serial("id").primaryKey(),
  userId: int("user_id").notNull(),
  title: varchar("title", { length: 255 }).default("New Chat"),
  agentKey: varchar("agent_key", { length: 100 }),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull().$onUpdate(() => new Date()),
});

// ─── Chat Messages ────────────────────────────────────────────
export const chatMessages = mysqlTable("chat_messages", {
  id: serial("id").primaryKey(),
  sessionId: int("session_id").notNull(),
  role: mysqlEnum("role", ["user", "assistant"]).notNull(),
  content: text("content").notNull(),
  model: varchar("model", { length: 100 }),
  tokensUsed: int("tokens_used"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── License Keys ─────────────────────────────────────────────
export const licenseKeys = mysqlTable("license_keys", {
  id: serial("id").primaryKey(),
  keyHash: varchar("key_hash", { length: 255 }).notNull().unique(),
  keyPrefix: varchar("key_prefix", { length: 50 }).notNull(),
  createdBy: int("created_by").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  isUsed: boolean("is_used").default(false),
  isRevoked: boolean("is_revoked").default(false),
  usedBy: int("used_by"),
  chatsUsed: int("chats_used").default(0),
  maxChats: int("max_chats").default(10),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type WebUser = typeof webUsers.$inferSelect;
export type InsertWebUser = typeof webUsers.$inferInsert;
export type ChatSession = typeof chatSessions.$inferSelect;
export type ChatMessage = typeof chatMessages.$inferSelect;
