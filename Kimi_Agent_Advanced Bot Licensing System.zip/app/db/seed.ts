import { getDb } from "../api/queries/connection";
import { webUsers } from "./schema";
import { createHash } from "crypto";

const db = getDb();

async function seed() {
  console.log("🌱 Seeding web portal users...");

  // Create a test web user (password: wormgpt123)
  const passwordHash = createHash("sha256").update("wormgpt123").digest("hex");

  try {
    await db.insert(webUsers).values({
      telegramId: "7818815949",
      username: "cybersniper",
      passwordHash,
      displayName: "CyberSniper",
      tier: "admin",
      isActive: true,
      expiresAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), // 1 year
      subscriptionDays: 365,
    });
    console.log("✅ Created test user: cybersniper / wormgpt123");
  } catch (e: any) {
    if (e.message?.includes("Duplicate")) {
      console.log("ℹ️ Test user already exists");
    } else {
      console.error("❌ Seed error:", e.message);
    }
  }

  // Create another test user (password: demo123)
  try {
    const demoHash = createHash("sha256").update("demo123").digest("hex");
    await db.insert(webUsers).values({
      telegramId: "123456789",
      username: "demo",
      passwordHash: demoHash,
      displayName: "Demo User",
      tier: "web",
      isActive: true,
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
      subscriptionDays: 30,
    });
    console.log("✅ Created demo user: demo / demo123");
  } catch (e: any) {
    if (e.message?.includes("Duplicate")) {
      console.log("ℹ️ Demo user already exists");
    } else {
      console.error("❌ Seed error:", e.message);
    }
  }

  console.log("🎉 Seed complete!");
}

seed().catch(console.error);
