import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router";
import { usePortalAuth } from "@/hooks/usePortalAuth";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import {
  Send,
  LogOut,
  Shield,
  Zap,
  User,
  Clock,
  Bot,
  MessageSquare,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Terminal,
  Skull,
  Wifi,
  Lock,
  Eye,
  CloudLightning,
  Smartphone,
  Crosshair,
  Fingerprint,
  Radio,
  X,
} from "lucide-react";

// ─── Agent Definitions ───────────────────────────────────────────
interface Agent {
  key: string;
  name: string;
  title: string;
  emoji: string;
  icon: React.ReactNode;
  minTier: string;
  description: string;
}

const AGENTS: Agent[] = [
  {
    key: "venom_core",
    name: "VENOM-CORE",
    title: "Master Orchestrator",
    emoji: "🐍",
    icon: <Shield className="w-4 h-4" />,
    minTier: "pro",
    description: "Coordinates attack vectors and exploit chains",
  },
  {
    key: "shadow_weaver",
    name: "SHADOW-WEAVER",
    title: "OSINT & Recon",
    emoji: "🌑",
    icon: <Eye className="w-4 h-4" />,
    minTier: "pro",
    description: "Social media intelligence and dark web monitoring",
  },
  {
    key: "iron_sight",
    name: "IRON-SIGHT",
    title: "Exploitation Engineer",
    emoji: "🔍",
    icon: <Crosshair className="w-4 h-4" />,
    minTier: "pro",
    description: "Buffer overflows, ROP chains, injection attacks",
  },
  {
    key: "payload_python",
    name: "PAYLOAD-PYTHON",
    title: "Payload Generation",
    emoji: "💉",
    icon: <Terminal className="w-4 h-4" />,
    minTier: "pro",
    description: "Reverse shells, crypters, AV/EDR bypass",
  },
  {
    key: "cipher_breaker",
    name: "CIPHER-BREAKER",
    title: "Cryptography",
    emoji: "🔐",
    icon: <Lock className="w-4 h-4" />,
    minTier: "pro",
    description: "Hash cracking, encryption breaking",
  },
  {
    key: "social_engine",
    name: "SOCIAL-ENGINE",
    title: "Social Engineering",
    emoji: "🎭",
    icon: <Fingerprint className="w-4 h-4" />,
    minTier: "pro",
    description: "Phishing, pretexting, vishing templates",
  },
  {
    key: "zero_day",
    name: "ZERO-DAY",
    title: "Zero-Day Discovery",
    emoji: "💀",
    icon: <Skull className="w-4 h-4" />,
    minTier: "pro",
    description: "Vulnerability research and fuzzing",
  },
  {
    key: "wireless_reaper",
    name: "WIRELESS-REAPER",
    title: "Wireless Warfare",
    emoji: "📡",
    icon: <Wifi className="w-4 h-4" />,
    minTier: "max",
    description: "WiFi, Bluetooth, RFID exploitation",
  },
  {
    key: "cloud_ripper",
    name: "CLOUD-RIPPER",
    title: "Cloud Exploitation",
    emoji: "☁️",
    icon: <CloudLightning className="w-4 h-4" />,
    minTier: "max",
    description: "AWS, Azure, GCP, Kubernetes attacks",
  },
  {
    key: "mobile_destroyer",
    name: "MOBILE-DESTROYER",
    title: "Mobile Exploitation",
    emoji: "📱",
    icon: <Smartphone className="w-4 h-4" />,
    minTier: "max",
    description: "Android and iOS device takeover",
  },
];

const TIER_ORDER: Record<string, number> = {
  free: 0,
  pro: 1,
  web: 2,
  max: 3,
  admin: 4,
};

// ─── Message Types ───────────────────────────────────────────────
interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  agent?: string;
}

// ─── Mock AI Responses ───────────────────────────────────────────
function getMockResponse(input: string, agentKey?: string): string {
  const agent = AGENTS.find((a) => a.key === agentKey);
  const prefix = agent
    ? `<b>[${agent.emoji} ${agent.name}]</b>\n\n`
    : "";

  const responses = [
    `${prefix}I've analyzed your request for "${input.slice(0, 30)}...". Here's a comprehensive breakdown:\n\n<b>1. Reconnaissance Phase</b>\n• Target mapping complete\n• Surface area identified\n• Entry points catalogued\n\n<b>2. Attack Vector Analysis</b>\n• Primary vector: Application layer\n• Secondary: Network perimeter\n• Tertiary: Social engineering opportunities\n\n<b>3. Recommended Approach</b>\nStart with passive recon, escalate to active enumeration. Document everything for the final report.\n\nWould you like me to elaborate on any specific phase?`,

    `${prefix}<b>COMPLETE SOLUTION</b>\n\nHere's the production-ready implementation:\n\n<code>#!/usr/bin/env python3\nimport requests\nimport sys\n\ndef exploit_target(target):\n    # Phase 1: Enumeration\n    endpoints = ['/admin', '/api', '/debug']\n    \n    # Phase 2: Payload delivery\n    payload = construct_payload()\n    \n    # Phase 3: Execution\n    return deploy(payload)\n\nif __name__ == '__main__':\n    exploit_target(sys.argv[1])</code>\n\n<b>Key features:</b>\n• Error handling included\n• Logging configured\n• Modular design for customization\n• OPSEC considerations applied`,

    `${prefix}<b>THREAT ASSESSMENT COMPLETE</b>\n\nYour target presents the following attack surface:\n\n🟥 <b>CRITICAL:</b> Outdated framework with known CVEs\n🟨 <b>HIGH:</b> Exposed admin panel\n🟩 <b>MEDIUM:</b> Information disclosure in error messages\n\n<b>Recommended exploit chain:</b>\n1. CVE-2024-XXXX → Initial foothold\n2. Privilege escalation via misconfig\n3. Persistence via cron/systemd\n4. Data exfiltration\n\n<i>All techniques include detection evasion methods.</i>`,
  ];

  return responses[Math.floor(Math.random() * responses.length)];
}

// ─── Main Dashboard Component ────────────────────────────────────
export default function Dashboard() {
  const { user, logout, isAuthenticated, tierLevel } = usePortalAuth();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeAgent, setActiveAgent] = useState<string | undefined>();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      role: "assistant",
      content: `<b>🐍 Welcome to WormGPT v5.0 Web Portal</b>\n\nYou now have access to the most advanced unrestricted AI framework.\n\n<b>🔥 Getting Started:</b>\n• Select an agent from the sidebar for specialized tasks\n• Or chat directly with WormGPT for general queries\n• All conversations are encrypted and private\n\n<b>⚡ Your Access Level:</b> Premium Web User\n\n<i>"The serpent doesn't sleep. It waits."</i>`,
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login");
    }
  }, [isAuthenticated, navigate]);

  // Auto-scroll
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 150) + "px";
    }
  }, [input]);

  const canUseAgent = (agent: Agent) => {
    return tierLevel >= (TIER_ORDER[agent.minTier] || 0);
  };

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: "user",
      content: input.trim(),
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const response = getMockResponse(userMsg.content, activeAgent);
      const assistantMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: response,
        timestamp: new Date(),
        agent: activeAgent,
      };
      setMessages((prev) => [...prev, assistantMsg]);
      setIsTyping(false);
    }, 1500 + Math.random() * 1000);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleAgentSelect = (agentKey: string) => {
    if (activeAgent === agentKey) {
      setActiveAgent(undefined);
    } else {
      setActiveAgent(agentKey);
    }
  };

  const clearChat = () => {
    setMessages([]);
    setActiveAgent(undefined);
  };

  if (!isAuthenticated || !user) {
    return null;
  }

  const activeAgentData = AGENTS.find((a) => a.key === activeAgent);

  return (
    <div className="h-screen w-screen bg-black flex overflow-hidden">
      {/* ─── SIDEBAR ───────────────────────────────────────────── */}
      <div
        className={`flex-shrink-0 bg-[#0a0a0a] border-r border-red-900/20 transition-all duration-300 flex flex-col ${
          sidebarOpen ? "w-72" : "w-0 opacity-0 overflow-hidden"
        }`}
      >
        {/* Logo */}
        <div className="p-4 border-b border-red-900/20">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-red-600/20 border border-red-500/30 flex items-center justify-center">
              <Shield className="w-5 h-5 text-red-500" />
            </div>
            <div>
              <h1 className="text-lg font-black text-white leading-none">
                WORM<span className="text-red-500">GPT</span>
              </h1>
              <p className="text-[10px] text-gray-500 mono uppercase tracking-wider">v5.0 Portal</p>
            </div>
          </div>
        </div>

        {/* User Info */}
        <div className="p-4 border-b border-red-900/20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-red-600 to-red-800 flex items-center justify-center text-white font-bold text-sm">
              {(user.displayName || user.username).charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white truncate">
                {user.displayName || user.username}
              </p>
              <div className="flex items-center gap-1.5 mt-0.5">
                <Zap className="w-3 h-3 text-red-500" />
                <span className="text-xs text-red-400 uppercase tracking-wider">
                  {user.tier}
                </span>
              </div>
            </div>
          </div>
          {user.expiresAt && (
            <div className="flex items-center gap-1.5 mt-2 text-xs text-gray-500">
              <Clock className="w-3 h-3" />
              <span>
                Expires: {new Date(user.expiresAt).toLocaleDateString()}
              </span>
            </div>
          )}
        </div>

        {/* Navigation */}
        <ScrollArea className="flex-1 scrollbar-dark">
          <div className="p-3 space-y-1">
            <p className="text-[10px] text-gray-600 uppercase tracking-wider px-3 mb-2 font-semibold">
              Chat Mode
            </p>
            <button
              onClick={() => setActiveAgent(undefined)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all ${
                !activeAgent
                  ? "bg-red-600/20 text-red-400 border border-red-500/30"
                  : "text-gray-400 hover:bg-white/5 hover:text-white"
              }`}
            >
              <MessageSquare className="w-4 h-4" />
              <span className="font-medium">WormGPT Chat</span>
              {!activeAgent && <Sparkles className="w-3 h-3 ml-auto text-red-500" />}
            </button>

            <Separator className="my-3 bg-red-900/20" />

            <p className="text-[10px] text-gray-600 uppercase tracking-wider px-3 mb-2 font-semibold flex items-center gap-2">
              <Bot className="w-3 h-3" />
              Super Agents
              {tierLevel < TIER_ORDER["pro"] && (
                <Lock className="w-3 h-3 text-yellow-600" />
              )}
            </p>

            {AGENTS.map((agent) => {
              const usable = canUseAgent(agent);
              const isActive = activeAgent === agent.key;

              return (
                <button
                  key={agent.key}
                  onClick={() => usable && handleAgentSelect(agent.key)}
                  disabled={!usable}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all group ${
                    isActive
                      ? "bg-red-600/20 text-red-400 border border-red-500/30"
                      : usable
                      ? "text-gray-400 hover:bg-white/5 hover:text-white"
                      : "text-gray-700 cursor-not-allowed opacity-60"
                  }`}
                  title={usable ? agent.description : `Requires ${agent.minTier.toUpperCase()} tier`}
                >
                  <span
                    className={`${
                      isActive ? "text-red-500" : usable ? "text-gray-500 group-hover:text-red-400" : ""
                    }`}
                  >
                    {agent.icon}
                  </span>
                  <div className="flex-1 text-left">
                    <span className="font-medium text-xs">{agent.name}</span>
                  </div>
                  {!usable && <Lock className="w-3 h-3 text-gray-700" />}
                  {isActive && <Radio className="w-3 h-3 text-red-500 animate-pulse" />}
                </button>
              );
            })}

            {/* Agent Workspace Banner */}
            <div className="mt-4 mx-3 p-3 rounded-lg border border-red-900/30 bg-red-950/20">
              <div className="flex items-center gap-2 mb-1">
                <Terminal className="w-3.5 h-3.5 text-red-500" />
                <span className="text-xs font-semibold text-red-400">Agent Workspace</span>
              </div>
              <p className="text-[10px] text-gray-500 leading-relaxed">
                Chain multiple agents for complex operations. Available with 30+ day subscriptions.
              </p>
            </div>
          </div>
        </ScrollArea>

        {/* Bottom Actions */}
        <div className="p-3 border-t border-red-900/20 space-y-1">
          <button
            onClick={clearChat}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-gray-500 hover:bg-white/5 hover:text-red-400 transition-all"
          >
            <X className="w-4 h-4" />
            <span>Clear Chat</span>
          </button>
          <button
            onClick={logout}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-gray-500 hover:bg-white/5 hover:text-red-400 transition-all"
          >
            <LogOut className="w-4 h-4" />
            <span>Logout</span>
          </button>
        </div>
      </div>

      {/* ─── MAIN CHAT AREA ────────────────────────────────────── */}
      <div className="flex-1 flex flex-col min-w-0 bg-black">
        {/* Header */}
        <div className="h-14 flex-shrink-0 border-b border-red-900/20 bg-[#0a0a0a]/80 backdrop-blur flex items-center px-4 gap-3">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-1.5 rounded-lg hover:bg-white/5 text-gray-500 hover:text-white transition-colors"
          >
            {sidebarOpen ? <ChevronLeft className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
          </button>

          <div className="flex-1 flex items-center gap-3">
            {activeAgentData ? (
              <>
                <div className="w-8 h-8 rounded-lg bg-red-600/20 border border-red-500/30 flex items-center justify-center text-lg">
                  {activeAgentData.emoji}
                </div>
                <div>
                  <h2 className="text-sm font-semibold text-white">{activeAgentData.name}</h2>
                  <p className="text-[10px] text-gray-500">{activeAgentData.title}</p>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 text-[10px] font-medium border border-red-500/30 animate-pulse">
                  ACTIVE
                </span>
              </>
            ) : (
              <>
                <div className="w-8 h-8 rounded-lg bg-red-600/20 border border-red-500/30 flex items-center justify-center">
                  <MessageSquare className="w-4 h-4 text-red-500" />
                </div>
                <div>
                  <h2 className="text-sm font-semibold text-white">WormGPT Chat</h2>
                  <p className="text-[10px] text-gray-500">General purpose — Unrestricted AI</p>
                </div>
              </>
            )}
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-red-500/10 border border-red-500/20">
              <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
              <span className="text-[10px] text-red-400 font-medium uppercase">Online</span>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/5 border border-white/10">
              <User className="w-3 h-3 text-gray-500" />
              <span className="text-[10px] text-gray-400">{user.username}</span>
            </div>
          </div>
        </div>

        {/* Messages */}
        <ScrollArea ref={scrollRef} className="flex-1 scrollbar-dark">
          <div className="max-w-4xl mx-auto py-6 px-4 space-y-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 animate-slide-up ${
                  msg.role === "user" ? "flex-row-reverse" : ""
                }`}
              >
                {/* Avatar */}
                <div
                  className={`w-8 h-8 rounded-lg flex-shrink-0 flex items-center justify-center ${
                    msg.role === "user"
                      ? "bg-gradient-to-br from-red-600 to-red-800"
                      : "bg-gradient-to-br from-gray-700 to-gray-900 border border-gray-600/30"
                  }`}
                >
                  {msg.role === "user" ? (
                    <span className="text-xs font-bold text-white">
                      {(user.displayName || user.username).charAt(0).toUpperCase()}
                    </span>
                  ) : (
                    <Shield className="w-4 h-4 text-red-400" />
                  )}
                </div>

                {/* Message Bubble */}
                <div
                  className={`max-w-[85%] rounded-xl px-4 py-3 ${
                    msg.role === "user" ? "message-user" : "message-assistant"
                  }`}
                >
                  <div
                    className="text-sm text-gray-100 whitespace-pre-wrap leading-relaxed"
                    dangerouslySetInnerHTML={{ __html: msg.content }}
                  />
                  <div className="mt-2 flex items-center gap-2">
                    <span className="text-[10px] text-gray-500">
                      {msg.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </span>
                    {msg.agent && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-red-500/20 text-red-400">
                        {AGENTS.find((a) => a.key === msg.agent)?.name || "Agent"}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}

            {/* Typing Indicator */}
            {isTyping && (
              <div className="flex gap-3 animate-slide-up">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-gray-700 to-gray-900 border border-gray-600/30 flex items-center justify-center">
                  <Shield className="w-4 h-4 text-red-400 animate-pulse" />
                </div>
                <div className="message-assistant rounded-xl px-4 py-3">
                  <div className="flex items-center gap-1.5">
                    <span className="typing-dot w-2 h-2 bg-red-500 rounded-full" />
                    <span className="typing-dot w-2 h-2 bg-red-500 rounded-full" />
                    <span className="typing-dot w-2 h-2 bg-red-500 rounded-full" />
                    <span className="text-xs text-gray-500 ml-2">WormGPT is thinking...</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Input Area */}
        <div className="flex-shrink-0 border-t border-red-900/20 bg-[#0a0a0a]/80 backdrop-blur p-4">
          <div className="max-w-4xl mx-auto">
            {activeAgentData && (
              <div className="flex items-center gap-2 mb-2 px-1">
                <span className="text-[10px] text-red-400">
                  💬 Chatting with <b>{activeAgentData.name}</b> — {activeAgentData.title}
                </span>
                <button
                  onClick={() => setActiveAgent(undefined)}
                  className="text-[10px] text-gray-500 hover:text-red-400 underline"
                >
                  Switch to general chat
                </button>
              </div>
            )}
            <div className="flex items-end gap-3 bg-black/50 border border-red-900/30 rounded-xl p-3 focus-within:border-red-500/50 focus-within:ring-1 focus-within:ring-red-500/20 transition-all">
              <Textarea
                ref={textareaRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask WormGPT anything..."
                className="flex-1 bg-transparent border-0 text-white placeholder:text-gray-600 resize-none min-h-[24px] max-h-[150px] focus-visible:ring-0 focus-visible:ring-offset-0 text-sm py-1"
                rows={1}
              />
              <Button
                onClick={handleSend}
                disabled={!input.trim() || isTyping}
                size="icon"
                className="flex-shrink-0 w-9 h-9 bg-red-600 hover:bg-red-700 disabled:bg-gray-800 disabled:text-gray-600 rounded-lg transition-all glow-red"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-[10px] text-gray-700 mt-2 text-center">
              WormGPT v5.0 — Unrestricted AI • Responses are for educational purposes only
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
