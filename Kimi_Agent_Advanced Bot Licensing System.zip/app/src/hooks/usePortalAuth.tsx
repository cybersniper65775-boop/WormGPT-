import { createContext, useContext, useState, useCallback, type ReactNode } from "react";

export interface PortalUser {
  id: number;
  username: string;
  displayName: string | null;
  tier: "free" | "pro" | "max" | "web" | "admin";
  expiresAt: string | null;
  isActive: boolean;
}

interface PortalAuthContext {
  user: PortalUser | null;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  isAuthenticated: boolean;
  tierLevel: number;
}

const PortalAuthContext = createContext<PortalAuthContext | null>(null);

const TIER_LEVELS: Record<string, number> = {
  free: 0,
  pro: 1,
  web: 2,
  max: 3,
  admin: 4,
};

export function PortalAuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<PortalUser | null>(() => {
    const stored = localStorage.getItem("portal_user");
    if (stored) {
      try {
        return JSON.parse(stored);
      } catch {
        return null;
      }
    }
    return null;
  });
  const [isLoading, setIsLoading] = useState(false);

  const login = useCallback(async (username: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    try {
      const res = await fetch("/api/portal/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });

      if (!res.ok) {
        return false;
      }

      const data = await res.json();
      if (data.success && data.user) {
        setUser(data.user);
        localStorage.setItem("portal_user", JSON.stringify(data.user));
        localStorage.setItem("portal_token", data.token || "");
        return true;
      }
      return false;
    } catch {
      return false;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    localStorage.removeItem("portal_user");
    localStorage.removeItem("portal_token");
  }, []);

  const tierLevel = user ? TIER_LEVELS[user.tier] || 0 : -1;

  return (
    <PortalAuthContext.Provider
      value={{
        user,
        isLoading,
        login,
        logout,
        isAuthenticated: !!user,
        tierLevel,
      }}
    >
      {children}
    </PortalAuthContext.Provider>
  );
}

export function usePortalAuth() {
  const ctx = useContext(PortalAuthContext);
  if (!ctx) {
    throw new Error("usePortalAuth must be used within PortalAuthProvider");
  }
  return ctx;
}
