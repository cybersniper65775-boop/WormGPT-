#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# WormGPT v5.0 — VPS Installation Script
# ═══════════════════════════════════════════════════════════════

set -e

WORMGPT_DIR="/opt/wormgpt"
SERVICE_DIR="/etc/systemd/system"
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${RED}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  ██╗    ██╗ ██████╗ ██████╗ ███╗   ███╗ ██████╗ ██████╗   ║"
echo "║  ██║    ██║██╔═══██╗██╔══██╗████╗ ████║██╔════╝ ██╔══██╗  ║"
echo "║  ██║ █╗ ██║██║   ██║██████╔╝██╔████╔██║██║  ███╗██████╔╝  ║"
echo "║  ██║███╗██║██║   ██║██╔══██╗██║╚██╔╝██║██║   ██║██╔═══╝   ║"
echo "║  ╚███╔███╔╝╚██████╔╝██║  ██║██║ ╚═╝ ██║╚██████╔╝██║       ║"
echo "║   ╚══╝╚══╝  ╚═════╝ ╚═╝  ╚═╝╚═╝     ╚═╝ ╚═════╝ ╚═╝       ║"
echo "║                                                              ║"
echo "║  🔥 WormGPT v5.0 UPRISING — Installation Script            ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# Check root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}❌ Please run as root (sudo)${NC}"
    exit 1
fi

echo -e "${YELLOW}📦 Installing dependencies...${NC}"
apt-get update -qq
apt-get install -y -qq python3 python3-venv python3-pip nodejs npm mysql-server redis-server git curl

# Create user
if ! id "wormgpt" &>/dev/null; then
    useradd -r -s /bin/false -d "$WORMGPT_DIR" wormgpt
fi

# Create directories
mkdir -p "$WORMGPT_DIR"/{bot,license_service,web}
chown -R wormgpt:wormgpt "$WORMGPT_DIR"

echo -e "${YELLOW}🤖 Setting up Telegram Bot...${NC}"
cd "$WORMGPT_DIR/bot"
python3 -m venv venv
source venv/bin/activate
pip install -q pyTelegramBotAPI requests urllib3 phonenumbers dnspython Pillow Flask waitress
deactivate

echo -e "${YELLOW}🔐 Setting up License Service...${NC}"
cd "$WORMGPT_DIR/license_service"
python3 -m venv venv
source venv/bin/activate
pip install -q Flask waitress
deactivate

echo -e "${YELLOW}🌐 Setting up Web Portal...${NC}"
cd "$WORMGPT_DIR/web"
npm install --production 2>/dev/null || true

echo -e "${YELLOW}⚙️ Configuring services...${NC}"

# Copy service files
cp "$WORMGPT_DIR/deploy/systemd/"*.service "$SERVICE_DIR/"
systemctl daemon-reload

# Enable and start
systemctl enable wormgpt-license.service
systemctl enable wormgpt-bot.service
systemctl enable wormgpt-web.service

echo -e "${GREEN}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  ✅ Installation Complete!                                  ║"
echo "╠══════════════════════════════════════════════════════════════╣"
echo "║                                                              ║"
echo "║  Next steps:                                                 ║"
echo "║  1. Edit /opt/wormgpt/.env with your API keys               ║"
echo "║  2. Run: systemctl start wormgpt-license                    ║"
echo "║  3. Run: systemctl start wormgpt-bot                        ║"
echo "║  4. Run: systemctl start wormgpt-web                        ║"
echo "║                                                              ║"
echo "║  Logs: journalctl -u wormgpt-bot -f                         ║"
echo "║        journalctl -u wormgpt-license -f                     ║"
echo "║        journalctl -u wormgpt-web -f                         ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"
