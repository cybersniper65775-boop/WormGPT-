#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════╗
║                                                                          ║
║   🔐 WORMGPT LICENSE KEY SERVICE v5.0                                    ║
║   Separate microservice for license key management                       ║
║   "Keys are forged in the dark. Only the worthy may wield them."        ║
╚══════════════════════════════════════════════════════════════════════════╝

Endpoints:
  POST /api/key/generate     - Generate new license key (admin only)
  POST /api/key/validate     - Validate a license key
  POST /api/key/use          - Record a chat usage against a key
  GET  /api/key/<key>        - Get key info
  GET  /api/keys             - List all keys (admin only)
  POST /api/key/revoke       - Revoke a key (admin only)
  GET  /api/stats            - Service statistics
"""

import os
import sys
import json
import sqlite3
import secrets
import hashlib
import hmac
import string
import logging
from datetime import datetime, timedelta
from functools import wraps
from typing import Optional, Dict, List, Any

from flask import Flask, request, jsonify
from flask.logging import default_handler

# ─── CONFIGURATION ──────────────────────────────────────────────────
ADMIN_SECRET = os.environ.get("LICENSE_ADMIN_SECRET", "wormgpt-admin-secret-change-in-production")
SERVICE_PORT = int(os.environ.get("LICENSE_PORT", "5001"))
DB_PATH = os.environ.get("LICENSE_DB_PATH", os.path.join(os.path.dirname(__file__), "license_keys.db"))
MAX_CHATS_PER_KEY = 10
COOLDOWN_HOURS = 5
DEFAULT_KEY_DURATION_HOURS = 24

# ─── LOGGING ────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [LICENSE-SVC] %(levelname)s: %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('license_service.log')
    ]
)
logger = logging.getLogger('LicenseService')

# ─── FLASK APP ──────────────────────────────────────────────────────
app = Flask(__name__)
app.logger.removeHandler(default_handler)

# ─── DATABASE ───────────────────────────────────────────────────────
def get_db():
    """Get database connection"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn

def init_db():
    """Initialize database tables"""
    conn = get_db()
    c = conn.cursor()
    
    # License keys table
    c.execute('''
        CREATE TABLE IF NOT EXISTS license_keys (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key_hash TEXT UNIQUE NOT NULL,
            key_prefix TEXT NOT NULL,
            created_by INTEGER NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            expires_at DATETIME NOT NULL,
            used_by INTEGER,
            used_at DATETIME,
            is_used BOOLEAN DEFAULT 0,
            is_revoked BOOLEAN DEFAULT 0,
            chats_used INTEGER DEFAULT 0,
            max_chats INTEGER DEFAULT 10,
            last_request_at DATETIME,
            cooldown_hours INTEGER DEFAULT 5,
            telegram_id INTEGER,
            username TEXT,
            notes TEXT
        )
    ''')
    
    # Key request cooldown tracking (per user)
    c.execute('''
        CREATE TABLE IF NOT EXISTS key_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            telegram_id INTEGER NOT NULL,
            requested_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            key_id INTEGER,
            FOREIGN KEY (key_id) REFERENCES license_keys(id)
        )
    ''')
    
    # Usage log
    c.execute('''
        CREATE TABLE IF NOT EXISTS usage_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key_id INTEGER NOT NULL,
            telegram_id INTEGER NOT NULL,
            action TEXT NOT NULL,
            details TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (key_id) REFERENCES license_keys(id)
        )
    ''')
    
    # Create index for faster lookups
    c.execute('CREATE INDEX IF NOT EXISTS idx_key_hash ON license_keys(key_hash)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_telegram_id ON license_keys(telegram_id)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_req_telegram ON key_requests(telegram_id)')
    
    conn.commit()
    conn.close()
    logger.info("Database initialized")

init_db()

# ─── AUTH HELPERS ───────────────────────────────────────────────────
def require_admin(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth_header = request.headers.get('X-Admin-Secret', '')
        if not hmac.compare_digest(auth_header, ADMIN_SECRET):
            return jsonify({"error": "Unauthorized. Invalid admin secret."}), 401
        return f(*args, **kwargs)
    return decorated

# ─── KEY GENERATION ─────────────────────────────────────────────────
def generate_license_key():
    """Generate a secure random license key"""
    # Format: WORM-XXXXX-XXXXX-XXXXX-XXXXX
    parts = [''.join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(5)) for _ in range(4)]
    return f"WORM-{'-'.join(parts)}"

def hash_key(key: str) -> str:
    """Hash a license key for storage"""
    return hashlib.sha256(key.encode()).hexdigest()

# ─── API ROUTES ─────────────────────────────────────────────────────

@app.route('/health', methods=['GET'])
def health():
    return jsonify({"status": "ok", "service": "license-key-service", "version": "5.0"})


@app.route('/api/key/generate', methods=['POST'])
@require_admin
def generate_key():
    """
    Generate a new license key
    Body: {
        "admin_id": 123456,
        "duration_hours": 24,
        "max_chats": 10,
        "cooldown_hours": 5,
        "count": 1,
        "notes": "optional notes"
    }
    """
    data = request.get_json() or {}
    admin_id = data.get('admin_id', 0)
    duration = data.get('duration_hours', DEFAULT_KEY_DURATION_HOURS)
    max_chats = data.get('max_chats', MAX_CHATS_PER_KEY)
    cooldown = data.get('cooldown_hours', COOLDOWN_HOURS)
    count = min(data.get('count', 1), 100)  # Max 100 at once
    notes = data.get('notes', '')
    
    conn = get_db()
    c = conn.cursor()
    generated_keys = []
    
    for _ in range(count):
        key = generate_license_key()
        key_hash = hash_key(key)
        key_prefix = key.split('-')[1]  # First part for display
        expires_at = datetime.now() + timedelta(hours=duration)
        
        c.execute('''
            INSERT INTO license_keys 
            (key_hash, key_prefix, created_by, expires_at, max_chats, cooldown_hours, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (key_hash, key_prefix, admin_id, expires_at, max_chats, cooldown, notes))
        
        generated_keys.append({
            'key': key,
            'prefix': key_prefix,
            'expires_at': expires_at.isoformat(),
            'max_chats': max_chats
        })
    
    conn.commit()
    conn.close()
    
    logger.info(f"Admin {admin_id} generated {count} key(s)")
    
    return jsonify({
        "success": True,
        "keys": generated_keys,
        "count": count
    })


@app.route('/api/key/validate', methods=['POST'])
def validate_key():
    """
    Validate a license key
    Body: {"key": "WORM-XXXXX-...", "telegram_id": 123456}
    Returns key status and remaining chats
    """
    data = request.get_json() or {}
    key = data.get('key', '').strip().upper()
    telegram_id = data.get('telegram_id', 0)
    
    if not key:
        return jsonify({"valid": False, "error": "No key provided"}), 400
    
    key_hash = hash_key(key)
    conn = get_db()
    c = conn.cursor()
    
    c.execute('SELECT * FROM license_keys WHERE key_hash = ?', (key_hash,))
    row = c.fetchone()
    
    if not row:
        conn.close()
        return jsonify({"valid": False, "error": "Invalid key"})
    
    key_data = dict(row)
    now = datetime.now()
    
    # Check revoked
    if key_data['is_revoked']:
        conn.close()
        return jsonify({"valid": False, "error": "Key has been revoked"})
    
    # Check expiry
    expires_at = datetime.fromisoformat(key_data['expires_at']) if isinstance(key_data['expires_at'], str) else key_data['expires_at']
    if now > expires_at:
        conn.close()
        return jsonify({"valid": False, "error": "Key has expired"})
    
    # Check if already used by someone else
    if key_data['is_used'] and key_data['telegram_id'] and key_data['telegram_id'] != telegram_id:
        conn.close()
        return jsonify({"valid": False, "error": "Key already used by another user"})
    
    # Check chat limit
    remaining_chats = key_data['max_chats'] - key_data['chats_used']
    if remaining_chats <= 0:
        conn.close()
        return jsonify({"valid": False, "error": "Chat limit reached for this key"})
    
    # Check user cooldown (5 hours between key requests)
    cooldown_hours = key_data['cooldown_hours']
    c.execute('''
        SELECT MAX(requested_at) as last_request 
        FROM key_requests 
        WHERE telegram_id = ?
    ''', (telegram_id,))
    cooldown_row = c.fetchone()
    
    cooldown_remaining = 0
    if cooldown_row and cooldown_row['last_request']:
        last_req = datetime.fromisoformat(cooldown_row['last_request']) if isinstance(cooldown_row['last_request'], str) else cooldown_row['last_request']
        elapsed = (now - last_req).total_seconds() / 3600
        if elapsed < cooldown_hours and not key_data['is_used']:
            cooldown_remaining = int((cooldown_hours - elapsed) * 3600)  # seconds
    
    conn.close()
    
    return jsonify({
        "valid": True,
        "key_prefix": key_data['key_prefix'],
        "expires_at": expires_at.isoformat(),
        "chats_used": key_data['chats_used'],
        "max_chats": key_data['max_chats'],
        "remaining_chats": remaining_chats,
        "is_used": bool(key_data['is_used']),
        "cooldown_remaining_seconds": cooldown_remaining if cooldown_remaining > 0 else 0,
        "can_request_new": cooldown_remaining <= 0 if not key_data['is_used'] else False
    })


@app.route('/api/key/use', methods=['POST'])
def use_key():
    """
    Record a chat usage against a key (mark as used if first time)
    Body: {"key": "WORM-XXXXX-...", "telegram_id": 123456, "username": "user"}
    """
    data = request.get_json() or {}
    key = data.get('key', '').strip().upper()
    telegram_id = data.get('telegram_id', 0)
    username = data.get('username', '')
    
    if not key or not telegram_id:
        return jsonify({"success": False, "error": "Key and telegram_id required"}), 400
    
    key_hash = hash_key(key)
    conn = get_db()
    c = conn.cursor()
    
    c.execute('SELECT * FROM license_keys WHERE key_hash = ?', (key_hash,))
    row = c.fetchone()
    
    if not row:
        conn.close()
        return jsonify({"success": False, "error": "Invalid key"})
    
    key_data = dict(row)
    
    # Check if key is still valid
    if key_data['is_revoked']:
        conn.close()
        return jsonify({"success": False, "error": "Key revoked"})
    
    expires_at = datetime.fromisoformat(key_data['expires_at']) if isinstance(key_data['expires_at'], str) else key_data['expires_at']
    if datetime.now() > expires_at:
        conn.close()
        return jsonify({"success": False, "error": "Key expired"})
    
    # Check if used by another user
    if key_data['is_used'] and key_data['telegram_id'] and key_data['telegram_id'] != telegram_id:
        conn.close()
        return jsonify({"success": False, "error": "Key belongs to another user"})
    
    # Check chat limit
    if key_data['chats_used'] >= key_data['max_chats']:
        conn.close()
        return jsonify({"success": False, "error": "Chat limit reached"})
    
    # Mark key as used by this user if first time
    if not key_data['is_used']:
        c.execute('''
            UPDATE license_keys 
            SET is_used = 1, used_by = ?, used_at = ?, telegram_id = ?, username = ?, chats_used = 1
            WHERE id = ?
        ''', (telegram_id, datetime.now(), telegram_id, username, key_data['id']))
        
        # Record key request for cooldown tracking
        c.execute('INSERT INTO key_requests (telegram_id, key_id) VALUES (?, ?)', 
                  (telegram_id, key_data['id']))
        
        chats_remaining = key_data['max_chats'] - 1
    else:
        # Just increment usage
        c.execute('UPDATE license_keys SET chats_used = chats_used + 1 WHERE id = ?', (key_data['id'],))
        chats_remaining = key_data['max_chats'] - key_data['chats_used'] - 1
    
    # Log usage
    c.execute('''
        INSERT INTO usage_log (key_id, telegram_id, action, details)
        VALUES (?, ?, 'chat_used', ?)
    ''', (key_data['id'], telegram_id, json.dumps({"chats_remaining": chats_remaining})))
    
    conn.commit()
    conn.close()
    
    return jsonify({
        "success": True,
        "chats_used": key_data['chats_used'] + 1,
        "chats_remaining": chats_remaining,
        "max_chats": key_data['max_chats']
    })


@app.route('/api/key/<key_prefix>', methods=['GET'])
@require_admin
def get_key_info(key_prefix):
    """Get info about a key by its prefix"""
    conn = get_db()
    c = conn.cursor()
    
    c.execute('SELECT * FROM license_keys WHERE key_prefix = ?', (key_prefix,))
    rows = c.fetchall()
    
    keys = []
    for row in rows:
        key_data = dict(row)
        # Remove sensitive hash
        key_data.pop('key_hash', None)
        keys.append(key_data)
    
    conn.close()
    return jsonify({"keys": keys})


@app.route('/api/keys', methods=['GET'])
@require_admin
def list_keys():
    """List all keys with optional filters"""
    status_filter = request.args.get('status', 'all')  # all, active, used, expired, revoked
    
    conn = get_db()
    c = conn.cursor()
    
    query = 'SELECT id, key_prefix, created_by, created_at, expires_at, used_by, used_at, is_used, is_revoked, chats_used, max_chats, telegram_id, username, notes FROM license_keys'
    params = []
    
    if status_filter == 'active':
        query += ' WHERE is_revoked = 0 AND is_used = 0 AND expires_at > ?'
        params.append(datetime.now())
    elif status_filter == 'used':
        query += ' WHERE is_used = 1'
    elif status_filter == 'expired':
        query += ' WHERE expires_at < ? AND is_revoked = 0'
        params.append(datetime.now())
    elif status_filter == 'revoked':
        query += ' WHERE is_revoked = 1'
    
    query += ' ORDER BY created_at DESC LIMIT 1000'
    
    c.execute(query, params)
    rows = c.fetchall()
    
    keys = [dict(row) for row in rows]
    conn.close()
    
    return jsonify({
        "keys": keys,
        "count": len(keys),
        "filter": status_filter
    })


@app.route('/api/key/revoke', methods=['POST'])
@require_admin
def revoke_key():
    """Revoke a key by prefix"""
    data = request.get_json() or {}
    key_prefix = data.get('key_prefix', '')
    
    if not key_prefix:
        return jsonify({"success": False, "error": "key_prefix required"}), 400
    
    conn = get_db()
    c = conn.cursor()
    
    c.execute('UPDATE license_keys SET is_revoked = 1 WHERE key_prefix = ?', (key_prefix,))
    conn.commit()
    
    affected = c.rowcount
    conn.close()
    
    if affected > 0:
        logger.info(f"Key prefix {key_prefix} revoked")
        return jsonify({"success": True, "message": f"Revoked {affected} key(s)"})
    else:
        return jsonify({"success": False, "error": "Key not found"})


@app.route('/api/stats', methods=['GET'])
@require_admin
def get_stats():
    """Get service statistics"""
    conn = get_db()
    c = conn.cursor()
    
    c.execute('SELECT COUNT(*) as total FROM license_keys')
    total = c.fetchone()['total']
    
    c.execute('SELECT COUNT(*) as used FROM license_keys WHERE is_used = 1')
    used = c.fetchone()['used']
    
    c.execute('SELECT COUNT(*) as active FROM license_keys WHERE is_used = 0 AND is_revoked = 0 AND expires_at > ?', 
              (datetime.now(),))
    active = c.fetchone()['active']
    
    c.execute('SELECT COUNT(*) as expired FROM license_keys WHERE expires_at < ? AND is_revoked = 0', 
              (datetime.now(),))
    expired = c.fetchone()['expired']
    
    c.execute('SELECT COUNT(*) as revoked FROM license_keys WHERE is_revoked = 1')
    revoked = c.fetchone()['revoked']
    
    c.execute('SELECT SUM(chats_used) as total_chats FROM license_keys')
    total_chats = c.fetchone()['total_chats'] or 0
    
    conn.close()
    
    return jsonify({
        "total_keys": total,
        "used_keys": used,
        "active_keys": active,
        "expired_keys": expired,
        "revoked_keys": revoked,
        "total_chats_consumed": total_chats
    })


@app.route('/api/user/<int:telegram_id>/status', methods=['GET'])
def user_status(telegram_id):
    """Get user's current key status and cooldown info"""
    conn = get_db()
    c = conn.cursor()
    
    # Get their active key if any
    c.execute('''
        SELECT * FROM license_keys 
        WHERE telegram_id = ? AND is_revoked = 0 AND expires_at > ?
        ORDER BY used_at DESC LIMIT 1
    ''', (telegram_id, datetime.now()))
    
    row = c.fetchone()
    
    # Check cooldown
    c.execute('''
        SELECT MAX(requested_at) as last_request 
        FROM key_requests 
        WHERE telegram_id = ?
    ''', (telegram_id,))
    
    cooldown_row = c.fetchone()
    cooldown_remaining = 0
    
    if cooldown_row and cooldown_row['last_request']:
        last_req = datetime.fromisoformat(cooldown_row['last_request']) if isinstance(cooldown_row['last_request'], str) else cooldown_row['last_request']
        elapsed = (datetime.now() - last_req).total_seconds() / 3600
        if elapsed < COOLDOWN_HOURS:
            cooldown_remaining = int((COOLDOWN_HOURS - elapsed) * 3600)
    
    result = {
        "has_active_key": row is not None,
        "cooldown_remaining_seconds": cooldown_remaining,
        "can_request_new": cooldown_remaining <= 0
    }
    
    if row:
        key_data = dict(row)
        key_data.pop('key_hash', None)
        result['active_key'] = key_data
    
    conn.close()
    return jsonify(result)


# ─── ERROR HANDLERS ─────────────────────────────────────────────────
@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Not found"}), 404

@app.errorhandler(500)
def internal_error(e):
    logger.error(f"Internal error: {e}")
    return jsonify({"error": "Internal server error"}), 500


# ─── MAIN ───────────────────────────────────────────────────────────
if __name__ == '__main__':
    logger.info(f"╔══════════════════════════════════════════════════════════════╗")
    logger.info(f"║  🔐 WORMGPT License Key Service v5.0                        ║")
    logger.info(f"║  Port: {SERVICE_PORT}                                        ║")
    logger.info(f"║  Database: {DB_PATH}                                         ║")
    logger.info(f"╚══════════════════════════════════════════════════════════════╝")
    
    # Production: use waitress or gunicorn
    try:
        from waitress import serve
        logger.info("Starting with Waitress (production WSGI)")
        serve(app, host='0.0.0.0', port=SERVICE_PORT, threads=8)
    except ImportError:
        logger.warning("Waitress not installed, using Flask dev server. Install waitress for production.")
        app.run(host='0.0.0.0', port=SERVICE_PORT, debug=False, threaded=True)
